export {}; //coment this if you ts-node to start complaining again
module.exports = 'test-file-stub';
