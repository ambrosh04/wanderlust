export default () => {
  process.exit(0);
};
